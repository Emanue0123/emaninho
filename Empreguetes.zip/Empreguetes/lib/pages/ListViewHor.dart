import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tips_and_tricks/pages/Login.dart';


class ListViewHor extends StatefulWidget {

  static final tag = 'ListViewHor-page';
  
  // ListViewHor({Key key, this.title}) : super(key: key);
 

  // final String title;
  
  @override
  _ListViewHorState createState() => _ListViewHorState();
}

class _ListViewHorState extends State<ListViewHor> {
  bool _validate = false;
  String nome,email,telefone,cpf,disponibilidade,chance,voce;
  String _validarNome(String value) {
    String patttern = r'(^[a-zA-Z ]*$)';
    RegExp regExp = new RegExp(patttern);
    if (value.length == 0) {
      return "Informe o nome";
    } else if (!regExp.hasMatch(value)) {
      return "O nome deve conter caracteres de a-z ou A-Z";
    }
    return null;
  }
   String _validarcelular(String value) {
    String patttern = r'(^[0-9]*$)';
    RegExp regExp = new RegExp(patttern);
    if (value.length == 0) {
      return "Informe o celular";
    } else if(value.length != 11){
      return "O celular deve ter 11 dígitos";
    }else if (!regExp.hasMatch(value)) {
      return "O número do celular so deve conter dígitos";
    }
    return null;
  }
    String _validarEmail(String value) {
    String pattern =  r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = new RegExp(pattern);
    if (value.length == 0) {
      return "Informe o Email";
    } else if(!regExp.hasMatch(value)){
      return "Email inválido";
    }else {
      return null;
    }
  }
  String _validarExp(String value) {
    String pattern =  r'(^[a-zA-Z ]*$)';
    RegExp regExp = new RegExp(pattern);
    if (value.length == 0) {
      return " Informe uma experiencia valida";
    } else if(!regExp.hasMatch(value)){
      return "Tem que ter apenas letras e não numeros nesse campo";
    }else {
      return null;
    }
  }
  String _validadeDisponibilidade(String value) {
    String pattern =  r'(^[0-9-a-zA-Z ]*$)';
    RegExp regExp = new RegExp(pattern);
    if (value.length == 0) {
      return "Informe um horário valido";
    } else if(!regExp.hasMatch(value)){
      return "Horario informado inválido";
    }else {
      return null;
    }
  }
  String _validarSalario(String value) {
    String pattern =  r'(^[0-9-a-zA-Z ]*$)';
    RegExp regExp = new RegExp(pattern);
    if (value.length == 0) {
      return "Informe um salario estimado";
    } else if(!regExp.hasMatch(value)){
      return "Digitou algo errado";
    }else {
      return null;
    }
  }
  
   var formKey = GlobalKey<FormState>();

  @override

  Widget build(BuildContext context) {
   var appBar = AppBar(
      title: Text("Cadastro de empregadas"),
      
    );
    
    var txtNome = TextFormField(
      decoration: InputDecoration(
        labelText: "Nome",
        hintText: "Digite o nome completo",
        icon: Icon(Icons.person)
      ),
      maxLines: 1,
      validator: _validarNome,
      onSaved: (value) {
        nome = value;
      },
    );

     var txtEmail = TextFormField(
      decoration: InputDecoration(
        labelText: "E-mail",
        icon: Icon(Icons.mail)
      ),
       keyboardType: TextInputType.emailAddress,
       maxLines: 2,
       validator: _validarEmail,
      onSaved: (value) => email = value,
    
     );

    var txtTelefone = TextFormField(
      decoration: InputDecoration(
        
        labelText: "Telefone(de preferencia com whatsapp)",
        hintText: "exemplo : 17991886598",
        icon: Icon(Icons.call)
      ),
      keyboardType: TextInputType.phone,
      maxLines: 2,
      validator: _validarcelular,
      onSaved: (value) => telefone = value,
    );
    var txtcpf = TextFormField(
      decoration: InputDecoration(
        labelText: "Cpf : ",
        hintText: "exemplo : 32131030890",
        icon: Icon(Icons.list)
      ),
      keyboardType: TextInputType.number,
      maxLines: 2,
      onSaved: (value) => cpf = value,
    );
    var txtdisponibilidade = TextFormField(
      decoration: InputDecoration(
        labelText: "Seu Horário disponivel : ",
        hintText: "exemplo : 17 horas as 19 horas",
        icon: Icon(Icons.access_alarm)
      ),
      keyboardType: TextInputType.text,
      maxLines: 2,
      validator: _validadeDisponibilidade,
      onSaved: (value) => disponibilidade = value,
    );
    var txtchance = TextFormField(
      decoration: InputDecoration(
        labelText: "Cite suas Experiencias profissionais : ",
        icon: Icon(Icons.list)
      ),
      keyboardType: TextInputType.text,
      maxLines: 2,
      validator: _validarExp,
      onSaved: (value) => chance = value,
    );
    var txtvoce = TextFormField(
     decoration: InputDecoration(
        labelText: "Pretensão salarial : (não esqueça o reais na frente)",
         hintText: "exemplo : 1800 reais ",
         icon: Icon(Icons.money_off)
     ),
     keyboardType: TextInputType.text,
     validator: _validarSalario,
     onSaved: (value) => voce = value,
    );

    var btnSalvar = RaisedButton(
      child: Text(" Cadastrar - se   ",
                     style: TextStyle(color: Colors.white, fontSize: 14),
                   ), 
             color: Theme.of(context).accentColor,
            
          
      
      onPressed: () {
        if (formKey.currentState.validate()) {
        formKey.currentState.save();
        
        Firestore.instance
          .collection('todolist')
          .add({
            "nome": nome,
            "email" : email,
            "telefone" : telefone,
            "cpf"  : cpf,
            "disponibilidade" : disponibilidade,
            'chance' : chance,
            'voce' : voce  });  
        

         Navigator.of(context).pushNamed(Login.tag);
      }
      else {
      // erro de validação
      setState(() {
        
        _validate = true;
      });
            }
          },    
      
      shape: new RoundedRectangleBorder(borderRadius:
  new BorderRadius.circular(20.0)),  
    );
    
    
      
    
    var lista =
ListView(
       children: <Widget>[
         
        txtNome,
        txtEmail,
        txtTelefone,
        txtcpf,
        txtdisponibilidade,
        txtvoce,
        txtchance,
        btnSalvar,
        
            ],
       
      
    );
    
    var form = Form(key: formKey, autovalidate: _validate,child: lista    );

    return Scaffold(
      appBar: appBar,
      body:

        form
        
        ); 
  
  }

  }
   
   
 


