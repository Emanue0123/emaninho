import 'package:flutter/material.dart';


class DragNDropPage extends StatefulWidget {

  static String tag = 'dragndrop-page';

  @override
  _DragNDropPageState createState() => _DragNDropPageState();
}

class _DragNDropPageState extends State<DragNDropPage> with TickerProviderStateMixin {

  bool accepted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
     appBar: AppBar(title: Text('Divulgue sua oportunidade '), ),
     body: Container(color: Colors.white,child: oportunidade(),),    
    );
     

  }
   
   oportunidade(){{
       //camera(uma foto sua ou do local da faxina)
       //valor a ser pago para o contratado
       //horas a serem trabalhadas(tempo)
       //local a ser limpado
    return Padding(padding:  EdgeInsets.fromLTRB(3, 1, 0, 10),
    child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly,children : 
      [ 
       
        TextField(
  
            decoration:
            InputDecoration(border: 
            InputBorder.none,
            icon: Icon(Icons.person),
            hintText: 'Se tiver algum local específico para limpeza,diga sim ou não e informe o local se necessário',hintMaxLines: 23),
          ),

           TextField(
  
            decoration:
            InputDecoration(border: 
            InputBorder.none,
            icon: Icon(Icons.timer),
            hintText: 'Informe o tempo estimado de trabalho'),
          ),
          
         TextField(
             decoration:
             InputDecoration(border: 
             InputBorder.none,
             icon: Icon(Icons.attach_money),
             hintText: 'Qual o valor estimado da diária ou emprego fixo a ser pago para o contratante? ',hintMaxLines: 20,),
          ),
          
          TextField(
             decoration:
             InputDecoration(border: 
             InputBorder.none,
             icon: Icon(Icons.archive),
             hintText: 'Anexe aqui uma foto sua ou do local da faxina(é interessante colocar por conta da confiança ao contratado)',hintMaxLines: 20,),
          ),

          RaisedButton(child: Text('DIVULGAR OPORTUNIDADE')
          ,color: Colors.blueAccent,
          textColor: Colors.white,
          splashColor: Colors.yellow,padding: EdgeInsets.all(18.0),onPressed: (){},shape: new RoundedRectangleBorder(borderRadius:
 new BorderRadius.circular(26.0)))]));
                    
     
           
            
           

   }}
  }
