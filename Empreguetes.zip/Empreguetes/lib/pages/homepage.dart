import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tips_and_tricks/pages/ListViewHor.dart';
import 'package:tips_and_tricks/pages/Login.dart';
import 'package:tips_and_tricks/pages/tabbar.dart';
import 'package:tips_and_tricks/pages/task.dart';
import 'package:tips_and_tricks/pages/taskscreen.dart';
import 'package:tips_and_tricks/services/firestoreservice.dart';


class MyHomePage extends StatefulWidget {
  static final tag = 'Home-Page';
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Task> items;
  FirestoreService fireServ = new FirestoreService();
  StreamSubscription<QuerySnapshot> todoTasks;

  @override
  void initState() {
    super.initState();

    items=new List();

    todoTasks?.cancel();
    todoTasks=fireServ.getTaskList().listen((QuerySnapshot snapshot){
        final List<Task> tasks=snapshot.documents
        .map((documentSnapshot) => Task. fromMap(documentSnapshot.data))
        .toList();

        setState(() {
        this.items = tasks;
      });
      
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: <Widget>[
          _myAppBar(context),
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height - 80,
            child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index)
                 {
                   
                  return Stack(children: <Widget>[

                      
                    // The containers in the background
                    Column(children: <Widget>[
                           
                      Padding(
                        padding: EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Container(
                          
                          width: MediaQuery.of(context).size.width,
                          height: 80.0,
                          child: Padding(
                            padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                            child: Material(
                              color: Colors.white,
                              elevation: 14.0,
                              shadowColor: Color(0x802196F3),
                              child: Center(
                                child: Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                        
                                    children: <Widget>[ 
                                     
                                      todoType('${items[index].tasktype}'),
                                      Text(
                                        '${items[index].taskname}',
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 20.0),
                                      ),

                      // Firestore.instance.runTransaction((transaction)async {
                      //   DocumentSnapshot freshDoc = await transaction.get(doc.reference);

                      //  await transaction.delete(freshDoc.reference);
                      // });

                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          
                                          Text(
                                            '${items[index].taskdate}',
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 18.0,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            '${items[index].tasktime}',
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 16.0),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ]),
                  ]);
                }),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFFFA7397),
        child: Icon(
          FontAwesomeIcons.listUl,
          color: Color(0xFFFDDE42),
        ),
        onPressed: () {
          //Navigator.push(context,MaterialPageRoute(builder: (context) => TaskScreen()),
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TaskScreen(Task('', '', '', '', '','','','','','','','')),
                fullscreenDialog: true),
          );
        },
      ),
    );
  }


  Widget todoType(String icontype) {
    IconData iconval;
    Color colorval;
    switch (icontype) {
      case 'travel':
         iconval = FontAwesomeIcons.check;
        colorval = Color(0xff4158ba);
        return CircleAvatar(
       backgroundColor: colorval,
      child: 
       FlatButton(child: Icon(
      iconval,color: Colors.white,size: 15.0,
       
                                        
     ),
     onPressed: () {Navigator.of(context).pushNamed(ListViewHor.tag);}),
   );
        break;
        
      case 'shopping':
        iconval = FontAwesomeIcons.check;
        colorval = Color(0xfffb537f);
        return CircleAvatar(
       backgroundColor: colorval,
      child: 
       FlatButton(child: Icon(
      iconval,color: Colors.white,size: 15.0,
       
                                        
     ),
     onPressed: () {Navigator.of(context).pushNamed(Login.tag);}),
   );
        break;
      case 'gym':
        iconval = FontAwesomeIcons.check;
        colorval = Color(0xff4caf50);
        break;
      case 'party':
        iconval = FontAwesomeIcons.check;
        colorval = Color(0xff9962d0);
        break;
      default:
         iconval = FontAwesomeIcons.check;
         colorval = Color(0xff0dc8f5);
      
    }
     return CircleAvatar(
       backgroundColor: colorval,
      child: 
       FlatButton(child: Icon(
      iconval,color: Colors.white,size: 15.0,
       
                                        
     ),
     onPressed: () {Navigator.of(context).pushNamed(ListViewHor.tag);}),
   );
    //    FontAwesomeIcons.check,
    //    color: Color(0xFFFDDE42),
                                        
    //  ),
    //  onPressed: () {Navigator.of(context).pushNamed(ListViewHor.tag);});
     // backgroundColor: colorval,
   //   child: Icon(iconval, color: Colors.white, size: 20.0),
    
  }

  Widget _myAppBar(context) {
    return Container(
      height: 80.0,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [
              const Color(0xFFFA7397),
              const Color(0xFFFDDE42),
            ],
            begin: const FractionalOffset(0.0, 0.0),
            end: const FractionalOffset(1.0, 0.0),
            stops: [0.0, 1.0],
            tileMode: TileMode.clamp),
      ),
      child: Padding(
        padding: const EdgeInsets.only(top: 16.0),
        child: Center(
            child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Expanded(
              flex: 1,
              child: Container(
                child: IconButton(
                    icon: Icon(
                      FontAwesomeIcons.arrowLeft,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      Navigator.of(context).pushNamed(TabBarPage.tag);
                    }),
              ),
            ),
            Expanded(
              flex: 5,
              child: Container(
                child: Text(
                  'Lista de Empregos',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 20.0),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                child: IconButton(
                    icon: Icon(
                      FontAwesomeIcons.search,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      //
                    }),
              ),
            ),
          ],
        )),
      ),
    );

  }
}