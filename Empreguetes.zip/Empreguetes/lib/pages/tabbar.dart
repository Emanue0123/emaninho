
import 'package:flutter/material.dart';
import 'package:tips_and_tricks/pages/ListViewHor.dart';
import 'package:tips_and_tricks/pages/Login.dart';
import 'package:tips_and_tricks/pages/homepage.dart';
import 'package:tips_and_tricks/services/authentication.dart';


 class TabBarPage extends StatefulWidget {
 TabBarPage({Key key, this.auth, this.userId, this.onSignedOut})
     : super(key: key);
 final BaseAuth auth;
 final VoidCallback onSignedOut;
 final String userId;

   static final tag = 'tabbar-page';
   @override
   _TabBarPageState createState() => _TabBarPageState();
 }
 class _TabBarPageState extends State<TabBarPage> with SingleTickerProviderStateMixin {
    final GlobalKey<FormState> formKey = GlobalKey<FormState>();



  @override
  void initState() {
    super.initState();
    
   

      
    
  }

  
 

 

 

  _signOut() async {
    try {
      await widget.auth.signOut();
      widget.onSignedOut();
    } catch (e) {
      print(e);
    }
  }

  
 
  @override
  Widget build(BuildContext context) {
    return  Scaffold(

      
        appBar: AppBar(
          
        title: Text(' HOUSE CLEANING  '),
        actions: <Widget>[
           new FlatButton(
           
           child: new Text('Sair da conta', 
           style: new TextStyle(fontSize: 15.0, color: Colors.white)),
          
           onPressed: _signOut),
           
           
           
        ],
         
 
        

      ),
      body: Container(
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [
              const Color(0xFFFA7397),
              const Color(0xFFFDDE42),
            ],
            begin: const FractionalOffset(0.0, 0.0),
            end: const FractionalOffset(1.0, 0.0),
            stops: [0.0, 1.0],
            tileMode: TileMode.clamp),
      ),child: widgetTextField(),),    
    );  
          
        
  }
          // actions: <Widget>[
          //    new FlatButton(
          //      child: new Text('Sair da sua conta',
          //           style: new TextStyle(fontSize: 17.0, color: Colors.white)),
          //        onPressed: _signOut),

        widgetTextField(){{
    return Padding(padding:  EdgeInsets.fromLTRB(10, 1, 0, 0),
    child: Column(mainAxisAlignment: MainAxisAlignment.start,crossAxisAlignment: CrossAxisAlignment.center,children :[
       
               SizedBox(height: 20),
             Text(' House Cleaning - Várias chances em um só aplicativo   ', style: TextStyle(color: Colors.black, fontSize: 16,backgroundColor: Colors.blueAccent)),
              SizedBox(height: 15),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset('assets/images/dono.jpg', scale: 1.11,height: 130,width: 300,),
             ),
             RaisedButton( 
             child: Text(
                     "Clique aqui para ver empregos ou criar uma oportunidade   ",
                     style: TextStyle(color: Colors.white, fontSize: 11),
                   ), 
             color: Theme.of(context).accentColor,
             padding: EdgeInsets.symmetric(vertical: 4.0 , horizontal: 4.0  ), 
             elevation : 50.0,
             splashColor: Colors.orange,
             onPressed: () {
                 Navigator.of(context).pushNamed(MyHomePage.tag);
             },
             shape: new RoundedRectangleBorder(borderRadius:
  new BorderRadius.circular(20.0)),
  

         
            
           
            ),
            ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset('assets/images/trabalho.jpg', scale: 0.1,height:130,width: 250,),
             ),
             RaisedButton( 
             child: Text(
                     "Lista de trabalhadoras domésticas disponíveis   ",
                     style: TextStyle(color: Colors.white, fontSize: 12),
                   ), 
             color: Theme.of(context).accentColor,
             padding: EdgeInsets.symmetric(vertical: 6.0 , horizontal: 6.0  ), 
             elevation : 50.0,
             splashColor: Colors.orange,
             onPressed: () {
                 Navigator.of(context).pushNamed(Login.tag);
             },
             shape: new RoundedRectangleBorder(borderRadius:
         new BorderRadius.circular(30.0)),
            ),
              ClipRRect(
                 borderRadius: BorderRadius.circular(10),
                 child: Image.asset('assets/images/domesticos.jpg', scale: 1.11,height: 120,width: 300,),
               ),
            RaisedButton( 
             child: Text(
                     "Clique aqui para se cadastrar como trabalhadora doméstica",
                     style: TextStyle(color: Colors.white, fontSize: 12),
                   ),
           
             color: Theme.of(context).accentColor,
             padding: EdgeInsets.symmetric(vertical: 4.0 , horizontal: 4.0  ), 
             elevation : 0.0,
             splashColor: Colors.orange,
             onPressed: () {
                 Navigator.of(context).pushNamed(ListViewHor.tag);
             },
             shape: new RoundedRectangleBorder(borderRadius:
  new BorderRadius.circular(20.0)),
  
    )]));
  }       
    

  

    
  
   

    
    
//   TabController _tabController;

//   @override
//   void initState() {
//     _tabController = TabController(length: 3, vsync: this);
//     super.initState();
//   }

//   @override
//   void dispose() {
//     _tabController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
    
//     var content = SingleChildScrollView(
      
            
//       child: Container(
        
//         color: Colors.black12,
//         height: MediaQuery.of(context).size.height - 80,
//         child: Center(
//           child: Column(
//             children: <Widget>[
//               SizedBox(height: 20),
//               Text(' House Cleaning - Dois em um, 1 emprego e 1 oportunidade para voce  ', style: TextStyle(color: Colors.black, fontSize: 12,backgroundColor: Colors.blueAccent)),
//               SizedBox(height: 15),
//               ClipRRect(
//                 borderRadius: BorderRadius.circular(10),
//                 child: Image.asset('assets/images/empregadas.jpg', scale: 0.1,height: 200,),
//               ),
        
          
          
//           RaisedButton( 
//             child: Text(
//                     "Clique aqui para ver empregos   ",
//                     style: TextStyle(color: Colors.white, fontSize: 20),
//                   ), 
//             color: Theme.of(context).accentColor,
//             padding: EdgeInsets.symmetric(vertical: 12.0 , horizontal: 12.0  ), 
//             elevation : 50.0,
//             splashColor: Colors.orange,
//             onPressed: () {
//                 Navigator.of(context).pushNamed(Login.tag);
//             },
//             shape: new RoundedRectangleBorder(borderRadius:
//  new BorderRadius.circular(20.0)),
 
           
              
             
//            ),
//              ClipRRect(
//                 borderRadius: BorderRadius.circular(10),
//                 child: Image.asset('assets/images/dono.jpg', scale: 0.1,height: 180,),
//               ),

//            RaisedButton( 
//             child: Text(
//                     "Clique aqui para oferecer uma oportunidade",
//                     style: TextStyle(color: Colors.white, fontSize: 15),
//                   ),
             
//             color: Theme.of(context).accentColor,
//             padding: EdgeInsets.symmetric(vertical: 10.0 , horizontal: 10.0  ), 
//             elevation : 0.0,
//             splashColor: Colors.orange,
//             onPressed: () {
//                 Navigator.of(context).pushNamed(ListViewSlide.tag);
//             },
//             shape: new RoundedRectangleBorder(borderRadius:
//  new BorderRadius.circular(30.0)),
 
           
              
             
//            ),
          
//            Center(
//          child: Container(
//          margin: const EdgeInsets.all(20.0),
//          width: 10.0,
//          height: 10.0,
//   ),
  

// ),
          
              
//             ],
//           ),
//         ),
//       ),
//     );

//      return Layout.getContent(context, content);
     
//   }
// }    
  }
 }
   
 
 

      