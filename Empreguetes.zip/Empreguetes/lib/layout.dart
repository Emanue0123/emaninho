import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'package:tips_and_tricks/pages/ListViewHor.dart';


import 'package:tips_and_tricks/pages/tabbar.dart';


class Layout {
  
   static int currItem = 0;
   static int currItem2 = 0;
   static BuildContext scaffoldContext;
   static final pages = [
    TabBarPage.tag,
    ListViewHor.tag,
    //HomePage.tag
  ];

   static Scaffold getContent(BuildContext context, content, [bool showbottom = true]){

    
        
   {
     BottomNavigationBar bottomNavBar = BottomNavigationBar(
        currentIndex: currItem,
      
      items: <BottomNavigationBarItem>[
        BottomNavigationBarItem(icon: Icon(Icons.home), title: Text('Home')),
        BottomNavigationBarItem(icon: Icon(Icons.question_answer), title: Text('Sobre')),
         BottomNavigationBarItem(icon: Icon(Icons.directions_run), title: Text('Deslogar'))
      ],
      onTap: (int i) {
        currItem = i;
        currItem2 = i;
        Navigator.of(context).pushReplacementNamed(pages[i]);
      },
    );  
    return Scaffold(   
      appBar: AppBar(
        title: Text(' HOUSE CLEANING  '),
        actions: showbottom ? _getActions(context) :[],
        

      ),
      bottomNavigationBar: showbottom ? bottomNavBar : null,
      body: Builder(builder: 
      (BuildContext context){
        Layout.scaffoldContext = context;
        return content;
      },
      
        
      ),
    );
    
   }

   
    
   

    




 

 
//       return Scaffold(
//         appBar:  AppBar(backgroundColor: Colors.blueAccent,
//         title: Text('Lista de empregos'),
//         actions: showbottom ? _getActions(context) : [],
//         ),
//       );
//  }
// }
   }
   
   static List<Widget> _getActions(BuildContext context) {

    List<Widget> items = List<Widget>();

    GlobalKey<FormState> _formKey = GlobalKey<FormState>();
    TextEditingController _c = TextEditingController();

    if (pages[currItem] == ListViewHor.tag) {
      items.add(
        GestureDetector(
          onTap: () {

            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (BuildContext ctx) {

                final input = Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _c,
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'Nome',
                      contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5)
                      )
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Este campo não pode ficar vazio';
                      }
                      return null;
                    },
                  )
                );

                return AlertDialog(
                  title: Text('Criar nova oportunidade'),
                  content: SingleChildScrollView(
                    child: ListBody(
                      children: <Widget>[
                        input
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    RaisedButton(
                      // color: secondary(),
                      child: Text('Cancelar',style: TextStyle(color: Layout.light())),
                      onPressed: () {
                        Navigator.of(ctx).pop();
                      },
                    ),
                    RaisedButton(
                      // color: primary(),
                      child: Text('Adicionar', style: TextStyle(color: Layout.light())),
                      onPressed: () {
                         Firestore.instance.collection('listas').add({
                           'nome' : _c.text
                         });


                        if (_formKey.currentState.validate()) {
                          //ModelLista listaBo = ModelLista();

                          // listaBo.insert({
                          //   'name': _c.text,
                          //   'created': DateTime.now().toString()
                          // }).then((newRowId) {

                          //   Navigator.of(ctx).pop();
                          //   Navigator.of(ctx).pushReplacementNamed(HomePage.tag);

                          // });
                        }
                        
                      },
                    )
                  ],
                );
              }
            );
          },
          child: Icon(Icons.add),
        )
      );
    }

    items.add(Padding(padding: EdgeInsets.only(right: 20)));

    return items;
  }

  static Color light([double opacity = 1]) => Color.fromRGBO(242, 234, 228, opacity);
}
final GlobalKey<FormState> formKey = GlobalKey<FormState>();


 

   

      
    

 
  