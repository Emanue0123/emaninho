

import 'package:flutter/material.dart';
import 'package:tips_and_tricks/pages/DragNDropPage.dart';
import 'package:tips_and_tricks/pages/ListViewHor.dart';
import 'package:tips_and_tricks/pages/Login.dart';
import 'package:tips_and_tricks/pages/homepage.dart';
import 'package:tips_and_tricks/pages/mains.dart';
import 'package:tips_and_tricks/pages/newtask.dart';
import 'package:tips_and_tricks/pages/root_page.dart';
import 'package:tips_and_tricks/pages/tabbar.dart';
import 'package:tips_and_tricks/services/authentication.dart';

 

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
   
   final routes = <String, WidgetBuilder> {
    ListViewHor.tag: (context) => ListViewHor(),
    //ListViewSlide.tag: (context) => ListViewSlide(),
    TabBarPage.tag: (context) => TabBarPage(),
     MyHomePage.tag: (context) => MyHomePage(),
    DragNDropPage.tag: (context) => DragNDropPage(),
    Login.tag: (context) => Login(),
     NewTask.tag: (context) => NewTask(),
     CreatToDo.tag: (context) => CreatToDo(),
    // HomePage.tag: (context) => MyApp(),
    
  //RegisterPage.tag: (context) => RegisterPage(),
  
   };
   
   final GlobalKey<FormState> formKey = GlobalKey<FormState>();
@override
 
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        focusColor: Colors.deepOrange
        
      ),
    
      home:RootPage(auth: Auth(),),
      routes: routes,
    );
  }





// // void main() => runApp(new MyApp());

// // class MyApp extends StatelessWidget {
  
// //   @override
// //   Widget build(BuildContext context) {
// //     return new MaterialApp(
// //       title: 'Pagina Inicial',
// //       theme: new ThemeData(
// //         primarySwatch: Colors.blue,
// //       ),
// //       home: new RootPage(auth: Auth(),)
// //     );
// //   }

// }

}
